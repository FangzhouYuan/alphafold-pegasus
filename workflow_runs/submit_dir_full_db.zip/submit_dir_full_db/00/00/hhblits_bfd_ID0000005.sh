#!/bin/bash
set -e
pegasus_lite_version_major="5"
pegasus_lite_version_minor="0"
pegasus_lite_version_patch="4dev"
pegasus_lite_enforce_strict_wp_check="true"
pegasus_lite_version_allow_wp_auto_download="true"


. pegasus-lite-common.sh

pegasus_lite_init

# cleanup in case of failures
trap pegasus_lite_signal_int INT
trap pegasus_lite_signal_term TERM
trap pegasus_lite_unexpected_exit EXIT

printf "\n########################[Pegasus Lite] Setting up workdir ########################\n"  1>&2
# work dir
pegasus_lite_setup_work_dir

printf "\n##############[Pegasus Lite] Figuring out the worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package

printf "\n#######################[Pegasus Lite] Staging in container #######################\n"  1>&2
# stage in container file 
pegasus-transfer --threads 1  1>&2 << 'EOF'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "singularity-container.sif",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///ocean/projects/asc190039p/zalam1/alphafold_container.sif", "priority": 100, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "symlink://$PWD/singularity-container.sif", "type": "singularity" }
   ] }
]
EOF

set -e

printf "\n########[Pegasus Lite] Writing out script to launch user task in container ########\n"  1>&2

cat <<EOF > hhblits_bfd_ID0000005-cont.sh
#!/bin/sh
printf "\n#################[Container] Now in pegasus lite container script #################\n"  1>&2
set -e

# tmp dirs are handled by Singularity - don't use the ones from the host
unset TEMP
unset TMP
unset TMPDIR

# setting environment variables for job
HOME=/srv
export HOME
EOF
container_env /srv >> hhblits_bfd_ID0000005-cont.sh
cat <<EOF2 >> hhblits_bfd_ID0000005-cont.sh
pegasus_lite_version_major=$pegasus_lite_version_major
pegasus_lite_version_minor=$pegasus_lite_version_minor
pegasus_lite_version_patch=$pegasus_lite_version_patch
pegasus_lite_enforce_strict_wp_check=$pegasus_lite_enforce_strict_wp_check
pegasus_lite_version_allow_wp_auto_download=$pegasus_lite_version_allow_wp_auto_download
pegasus_lite_inside_container=true
export pegasus_lite_work_dir=/srv

cd /srv
. ./pegasus-lite-common.sh
pegasus_lite_init

printf "\n##############[Container] Figuring out Pegasus worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package
printf "PATH in container is set to is set to \$PATH\n"  1>&2

printf "\n###################### Staging in input data and executables ######################\n"  1>&2
# stage in data and executables
pegasus-transfer --threads 1  --symlink  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "bfd.fasta",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///ocean/projects/asc190039p/zalam1/ParallelFold/data/bfd/bfd-first_non_consensus_sequences.fasta", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "symlink:///srv/bfd.fasta" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "GA98.fasta",
   "id": 2,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///ocean/projects/asc190039p/zalam1/GA98.fasta", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "symlink:///srv/GA98.fasta" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "hhblits_bfd",
   "id": 3,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///ocean/projects/asc190039p/zalam1/zalam1/pegasus/Alphafold-workflow/run0038/00/00/hhblits_bfd", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/hhblits_bfd" }
   ] }
]
eof

printf "\n##################### Setting the xbit for executables staged #####################\n"  1>&2
# set the xbit for any executables staged
/bin/chmod +x hhblits_bfd

set +e
job_ec=0
printf "\n#########################[Container] Launching user task #########################\n"  1>&2

pegasus-kickstart  -n hhblits_bfd -N ID0000005 -R condorpool  -s bfd_hits.sto=bfd_hits.sto -s bfd_msa_size.txt=bfd_msa_size.txt -L Alphafold-workflow -T 2023-01-14T00:25:20+00:00 ./hhblits_bfd GA98.fasta bfd.fasta bfd_hits.sto bfd_msa_size.txt
set -e
printf "\n############################ Staging out output files ############################\n"  1>&2
# stage out
pegasus-transfer --threads 1  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "output",
   "lfn": "bfd_hits.sto",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///srv/bfd_hits.sto", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///ocean/projects/asc190039p/zalam1/zalam1/pegasus/Alphafold-workflow/run0038/00/00/bfd_hits.sto" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "output",
   "lfn": "bfd_msa_size.txt",
   "id": 2,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///srv/bfd_msa_size.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///ocean/projects/asc190039p/zalam1/zalam1/pegasus/Alphafold-workflow/run0038/00/00/bfd_msa_size.txt" }
   ] }
]
eof

printf "\n################[Container] Exiting pegasus lite container script ################\n"  1>&2
EOF2


chmod +x hhblits_bfd_ID0000005-cont.sh
if ! [ $pegasus_lite_start_dir -ef . ]; then
	cp $pegasus_lite_start_dir/pegasus-lite-common.sh . 
fi

set +e
singularity_init singularity-container.sif
job_ec=$(($job_ec + $?))

singularity exec --no-home --bind $PWD:/srv --bind /ocean/projects/asc190039p/zalam1/zalam1/pegasus/Alphafold-workflow/run0038:/ocean/projects/asc190039p/zalam1/zalam1/pegasus/Alphafold-workflow/run0038 --bind /ocean/projects/asc190039p/zalam1:/ocean/projects/asc190039p/zalam1 singularity-container.sif /srv/hhblits_bfd_ID0000005-cont.sh 
job_ec=$(($job_ec + $?))


set -e


# clear the trap, and exit cleanly
trap - EXIT
pegasus_lite_final_exit

